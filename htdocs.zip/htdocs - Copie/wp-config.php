<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'planty' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '*j<jgW.$g:m!W_EeE*?%O:zc}AKs09DT$!GPt8ASCnwZm ~E)I;bHh0X:BFT!F~3' );
define( 'SECURE_AUTH_KEY',  '~TI(D] pV.q*C1EY -g<r@$L6$~St4eN?7+$H.L.*3XZZtZ$]qu)]F8gjjrU{-wn' );
define( 'LOGGED_IN_KEY',    '$~A^e=8*{u7Zc<cg4|TG/lL6}4V&{l,gQEE-h8<p{ f:*|yZH{IE7i<X3Cl&p*-E' );
define( 'NONCE_KEY',        'lA&4GhMjQmB(*%R~7hv6n!Uk6^<N}D>Qwu?ta|@8 ngYIlbp#TfBDp_V/=1;a8V]' );
define( 'AUTH_SALT',        'ZbR!aMhr.xVuwjXnKR(4]Gy{:imI;Rl;w>9f}W?t*>sFuttPaLz#.h83}B:c0u*f' );
define( 'SECURE_AUTH_SALT', 'B+Dgz<RP5j1?zU=!R1zncz41/7kWzB<-W =Sl.hHZmQTQ_:Kr-jE.mYT<l#}3{sN' );
define( 'LOGGED_IN_SALT',   'b3>*(+$L<C!NvoId%Eg&={exI1BQJ^<pj~Tl%i^LbsCP$MX_vt0YA V.x|]T.^(L' );
define( 'NONCE_SALT',       '[m} bhz{/xs%P9{)]!yc$.5gSuE>-Y/q_eWvvS~L{w1!E!$S+MzB_~ca5v)0s}o,' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
//define( 'WP_DEBUG', true );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
